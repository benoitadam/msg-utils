export default <T = any>(value: T): T => value;
