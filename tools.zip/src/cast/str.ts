import toString from './toString';

export default (v: any) => toString(v);
