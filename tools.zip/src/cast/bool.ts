import toBoolean from './toBoolean';

export default (v: any) => toBoolean(v);
