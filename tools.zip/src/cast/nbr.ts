import toNumber from './toNumber';

export default (v: any) => toNumber(v, 0);
