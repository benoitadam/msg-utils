export default (ms: number) => new Promise((r) => setTimeout(r, ms));
