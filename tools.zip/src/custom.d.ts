declare var __IS_BROWSER: boolean;
declare var __IS_NODE: boolean;

// declare var localStorage: {
//     getItem(key: string): string | null;
//     removeItem(key: string): void;
//     setItem(key: string, value: string): void;
// };

// declare var XMLHttpRequest: any