export default (value: any): value is Function => value instanceof Function;
