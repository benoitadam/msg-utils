export default Array.isArray;
