export default (value: any): value is string => typeof value === 'string';
