export default (value: any): value is Date => value instanceof Date;
