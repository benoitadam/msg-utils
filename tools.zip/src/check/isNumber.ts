export default (value: any): value is number => typeof value === 'number';
