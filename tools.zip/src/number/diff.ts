export default (arg1: number, arg2: number): number => Math.abs(arg1 - arg2);
