export default (min: number, max: number) => Math.random() * (max - min) + min;
